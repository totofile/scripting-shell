#!/bin/sh

################################################################################
# File: exo_1.sh
# Objet: 
# Usage: exo_1.sh
# Exemple: 
# Options: 
#  
# Retourne:
#   0: OK
#   1: 
# Auteur:
# Created: Fri 27 Mar 2020 10:43:41 AM CET
# Updated: Fri 27 Mar 2020 10:43:56 AM CET
################################################################################

echo "Hello world"

