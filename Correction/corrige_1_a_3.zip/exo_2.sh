#!/bin/sh

################################################################################
# File: exo_2.sh
# Objet: 
# Usage: exo_2.sh
# Exemple: 
# Options: 
#  
# Retourne:
#   0: OK
#   1: 
# Auteur:
# Created: Fri 27 Mar 2020 10:44:00 AM CET
# Updated: Fri 27 Mar 2020 10:45:18 AM CET
################################################################################

MSG="Hello world"

echo $MSG


